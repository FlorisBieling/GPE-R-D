# Asset Store texture dependency

## Source package

**Yughues Free Ground Materials**  
Publisher: Nobiax / Yughues  
Unity Asset Store:

https://assetstore.unity.com/packages/2d/textures-materials/nature/yughues-free-ground-materials-13001

## Texture mapping used by the editor utility

| Shader biome | Source base name |
|---|---|
| Water | `T_YFGM_FrozenGrass` |
| Beach | `T_YFGM_Mars` |
| Plains | `T_YFGM_Grass06` |
| Forest | `T_YFGM_Grass01` |
| Desert | `T_YFGM_Dry01` |
| Mountain | `T_YFGM_GroundStones02` |
| Snow | `T_YFGM_Snow` |

The utility expects `_d`, `_n`, and `_s` suffixes for albedo, normal and specular maps.

## Distribution

The original texture files are not included in this zip. Users should obtain them through the official Unity Asset Store package and comply with its license.
