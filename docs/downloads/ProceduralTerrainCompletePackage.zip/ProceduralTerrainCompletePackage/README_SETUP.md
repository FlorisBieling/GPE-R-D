# Procedural Terrain Complete Package

This package contains the current procedural terrain code, custom URP shader, material snapshot, editor texture-assignment utility, and camera controls.

## Important dependency

The terrain textures are not included. Import **Yughues Free Ground Materials** from the Unity Asset Store:

https://assetstore.unity.com/packages/2d/textures-materials/nature/yughues-free-ground-materials-13001

Raw Asset Store texture files are intentionally excluded from this package.

## Installation

1. Back up or commit the Unity project.
2. Copy `Assets/Perlin/` into the project.
3. Import Yughues Free Ground Materials.
4. Create or select a material using `Custom/ProceduralBiomeTexturesURP`.
5. Select the material and run:
   `Tools > Procedural Terrain > Assign Final YFGM Textures`
6. Check the Console for missing texture names.
7. Assign the material to `EndlessTerrain.mapMaterial`.

## Material warning

Unity materials store references using GUIDs from `.meta` files. The included `.mat` is a snapshot from the source project. When copied into another project without the original metadata, the shader or texture references may need to be assigned again.

## Camera filename changes

The supplied source project used:

- `Movement.cs` containing `TopDownCameraMovement`
- `CameraMovement.cs` containing `CameraHeightControl`

This package renames the files to match their MonoBehaviour class names:

- `TopDownCameraMovement.cs`
- `CameraHeightControl.cs`

## Editor folder

`AssignExactYFGMBiomeTextures_Final.cs` uses `UnityEditor` and `AssetDatabase`, so it is placed in `Assets/Perlin/Editor/`. It is not runtime code.

## Known shader limitations

- The shader samples two control maps plus seven albedo, seven normal and seven specular textures per fragment.
- World-space XZ projection can stretch on steep slopes.
- The tangent basis for normal mapping is reconstructed approximately.
- `_ColorMap` is declared but not currently sampled in the fragment result.
- The custom lighting model is simpler than URP Lit and focuses on the main light.
